<?php
require_once 'dataconectie.php';

$db = new Database();
$returnval = $db->customerLogin('test@fffk.nl', 'password');
echo $returnval;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tonobien</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: black;
            color: white;
        }

        header {
            background-color: black;
            color: white;
            padding: 20px;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }

        .logo {
            font-size: 24px;
            color: white;
            text-decoration: none;
            font-weight: 700;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 12px;
            border-bottom: 2px solid transparent;
            transition: border-bottom 0.3s ease-in-out;
        }

        .nav-links a:hover {
            border-bottom: 2px solid #3498db;
        }

        .car-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin: 20px;
            padding-top: 20px;
        }

        .car-card {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            background-color: #fff;
            transition: transform 0.3s ease-in-out;
        }

        .car-card:hover {
            transform: scale(1.05);
        }

        .car-card img {
            width: 100%;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .car-card h3 {
            color: black;
            font-size: 18px;
            margin: 10px 0;
        }

        .car-card p {
            color: #000000;
            font-size: 14px;
            margin: 5px 0;
        }

        .car-card button {
            background-color: #449bff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease-in-out;
        }

        .car-card button:hover {
            background-color: #007bb5;
        }

        footer {
        background-color: #333;
        color: white;
        padding: 20px 0;
        padding-left: 400px;
    }

    .footer-container {
        display: flex;
        justify-content: space-around;
    }

    .contact-info,
    .social-media {
        flex: 1;
    }

    h2 {
        color: #449bff;
    }

    ul {
        list-style: none;
        padding: 0;
    }

    li {
        margin-bottom: 10px;
    }

    strong {
        color: #449bff;
    }

    a img {
        width: 30px; /* Adjust the size of social media icons as needed */
        margin-right: 10px;
    }

    .footer-bottom {
        text-align: center;
        margin-top: 20px;
    }

    .footer-bottom p {
        margin: 0;
        font-size: 14px;
        padding-right: 350px;
    }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="home.php" class="logo">Tonobien</a>
            <div class="nav-links">
                <a href="http://localhost/osman%20data%20Niveau%204/data%20toets%20leerjaar%202%20periode%202/">Home</a>
                <a href="http://localhost/osman%20data%20Niveau%204/data%20toets%20leerjaar%202%20periode%202/huren.php">Over ons</a>
                <a href="http://localhost/osman%20data%20Niveau%204/data%20toets%20leerjaar%202%20periode%202/contact.php">Inloggen</a>
            </div>
        </nav>
    </header>

    <div class="car-container">
    <div class="car-card">
        <img src="mercedes cla.png" alt="Girl in a jacket"> 
        <h3>Mercedes cla</h3>
        <p>aankoopprijs</p>
        <button>voeg toe aan winkelwagen</button>
    </div>

    <div class="car-card">
        <img src="bmw x5.png" alt="Girl in a jacket"> 
        <h3>BMW X5</h3>
        <p>aankoopprijs</p>
        <button>voeg toe aan winkelwagen</button>
    </div>

    <div class="car-card">
        <img src="lamborgini.png" alt="Girl in a jacket"> 
        <h3>Lamborgini urus</h3>
        <p>aankoopprijs</p>
        <button>voeg toe aan winkelwagen</button>
    </div>

    <div class="car-card">
        <img src="bmw m5.png" alt="Girl in a jacket"> 
        <h3>BMW M5</h3>
        <p>aankoopprijs</p>
        <button>voeg toe aan winkelwagen</button>
    </div>

    <div class="car-card">
        <img src="rs6png.png" alt="Girl in a jacket">
        <h3>Audi
            RS6
            Plus Avant 5.0 TFSI *Audi</h3>
        <p>Aankoopprijs | € 60.000,-</p>
        <button>Voeg toe aan winkelwagen</button>
    </div>

    <div class="car-card">
        <img src="gwagon.png" alt="Girl in a jacket">  
        <h3>Mercedes Benz G-wagon</h3>
        <p>Aankoopprijs | € 55.000,-</p>
        <button>Voeg toe aan winkelwagen</button>
    </div>

    <div class="car-card">
        <img src="tesla modol s.png" alt="Girl in a jacket">
        <h3>Tesla modol s</h3>
        <p>Aankoopprijs</p>
        <button>Voeg toe aan winkelwagen</button>
    </div>
    </div>

    <footer>
    <div class="footer-container">
        <div class="contact-info">
            <h2>Contactgegevens</h2>
            <ul>
                <li><strong>E-Mail:</strong> info@tonobien.nl</li>
                <li><strong>Telefoon:</strong> +31 123 456 789</li>
                <li><strong>Adres:</strong> Straatnaam 123, 1234 AB Stad</li>
            </ul>
        </div>

        <div class="social-media">
            <h2>Volg ons</h2>
            <ul>
                <li><a href="#" target="_blank">Fasbook</a></li>
                <li><a href="#" target="_blank">Twitter</a></li>
                <li><a href="#" target="_blank">Instagram</a></li>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; 2024 Tonobien Autobedrijf Verhuur. Alle rechten voorbehouden.</p>
    </div>
</footer>
</body>
</html>
