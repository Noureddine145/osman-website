<?php
// Include necessary files
require_once 'db.php';
 
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $licenseNumber = $_POST['licenseNumber'];
    $phoneNumber = $_POST['phoneNumber'];
 
    // Validate form fields (you can add more validation as needed)
    if (empty($name) || empty($email) || empty($password) || empty($address) || empty($licenseNumber) || empty($phoneNumber)) {
        echo "All fields are required!";
    } else {
        // Create a new User object
        $user = new User();
 
        // Call the createCustomerAccount method to register the user
        $user->createCustomerAccount($name, $email, $password, $address, $licenseNumber, $phoneNumber);
 
        // Provide a message to the user
        echo "Registration successful! Redirecting to login page...";
 
        // Pause for 2 seconds
        sleep(2);
 
        // Redirect to the login page after registration
        header("Location: login.php");
        exit();
    }
}
?>
 
 
<!-- HTML form for registration -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
</head>
<body>
    <h2>Register</h2>
    <form method="post" action="register.php"> <!-- Update action to point to register.php -->
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>
 
        <label for="email">Email:</label>
        <input type="email" name="email" required><br>
 
        <label for="password">Password:</label>
        <input type="password" name="password" required><br>
 
        <label for="address">Address:</label>
        <input type="text" name="address" required><br>
 
        <label for="licenseNumber">License Number:</label>
        <input type="text" name="licenseNumber" required><br>
 
        <label for="phoneNumber">Phone Number:</label>
        <input type="text" name="phoneNumber" required><br>
 
        <input type="submit" value="Register">
    </form>
</body>
</html>