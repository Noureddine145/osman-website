<?php
session_start();
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tonobien</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: black;
            color: white;
        }
 
        header {
            background-color: black;
            color: white;
            padding: 20px;
        }
 
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }
 
        .logo {
            font-size: 24px;
            color: white;
            text-decoration: none;
            font-weight: 700;
        }
 
        .nav-links {
            display: flex;
            gap: 20px;
        }
 
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 12px;
            border-bottom: 2px solid transparent;
            transition: border-bottom 0.3s ease-in-out;
        }
 
        .nav-links a:hover {
            border-bottom: 2px solid #3498db;
        }
 
        .intro-section {
          background-image: url('intro sectie.png');
          background-size: cover;
          background-position: center;
          height: 400px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #ffffff;
          font-size: 20px;
        }
 
        .intro-text {
            text-align: center;
            color: black;
        }
 
        .intro-text p {
            padding-left: 360px;
            text-align: center;
            width: 50%;
            font-weight: bolder;
            font-size: 16px;
        }
 
        .car-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            padding-bottom: 30px;
            gap: 20px;
            margin: 20px;
            padding-top: 20px;
        }
 
        .car-card {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            background-color: #fff;
            transition: transform 0.3s ease-in-out;
        }
 
        .car-card:hover {
            transform: scale(1.05);
        }
 
        .car-card img {
            width: 100%;
            border-radius: 8px;
            margin-bottom: 10px;
        }
 
        .car-card h3 {
            color: black;
            font-size: 18px;
            margin: 10px 0;
        }
 
        .car-card p {
            color: #000000;
            font-size: 14px;
            margin: 5px 0;
        }
 
        .car-card button {
            background-color: #449bff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease-in-out;
        }
 
        .car-card button:hover {
            background-color: #007bb5;
        }
 
        footer {
        background-color: #333;
        color: white;
        padding: 20px 0;
        padding-left: 400px;
    }
 
    .footer-container {
        display: flex;
        justify-content: space-around;
    }
 
    .contact-info,
    .social-media {
        flex: 1;
    }
 
    h2 {
        color: #449bff;
    }
 
    ul {
        list-style: none;
        padding: 0;
    }
 
    li {
        margin-bottom: 10px;
    }
 
    strong {
        color: #449bff;
    }
 
    a img {
        width: 30px; /* Adjust the size of social media icons as needed */
        margin-right: 10px;
    }
 
    .footer-bottom {
        text-align: center;
        margin-top: 20px;
    }
 
    .footer-bottom p {
        margin: 0;
        font-size: 14px;
        padding-right: 350px;
    }
    </style>
</head>
<body>
 
           
 
    </head>
 
    <body>
        <nav>
            <a href="#" class="logo">Tonobien</a>
            <div class="nav-links">
                <a href="#">Auto's</a>
                <a href="#">Over ons</a>
 
                <?php
                // Check if the user is logged in and display appropriate button
                if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']) {
                    echo '<a href="logout.php" class="logout-link">Uitloggen</a>';
                } else {
                    echo '<a href="login.php" class="login-link">Inloggen</a>';
                }
                ?>
            </div>
        </nav>
        <div class="car-container">
    <?php
    // Controleer of $cars is ingesteld
    if ($cars) {
        foreach ($cars as $car) {
            $imageurl = "images/" . $car['image'];
    
            echo "<div class='car-details'>";
            echo "<h2>{$car['Merk']} {$car['Model']}</h2>";
            echo "<div class='image-container'>";
            echo "<img class='autoss' src='{$imageurl}' alt='{$car['Merk']} {$car['Model']}'>";
            echo "</div>";
            echo "<p>Year: {$car['Jaar']}</p>";
            echo "<p>Kenteken: {$car['Kenteken']}</p>";
    
            // Add other details if needed
    
            echo "</div>";
        }
    } else {
        echo "<p>No cars available.</p>";
    }
    ?>
 
    <section class="intro-section">
        <div class="intro-text">
            <h1>Welkom bij tonobien</h1>
            <p>Welkom bij Tonobien Autobedrijf Verhuur, waar de weg luxe en avontuur ontmoet. Ontdek een wereld van eersteklas voertuigen die zijn ontworpen om jouw rijervaring naar een hoger niveau te tillen. Ervaar de essentie van stijl, prestaties en comfort terwijl je begint aan onvergetelijke reizen met onze zorgvuldig samengestelde vloot. Jouw reis begint bij ons - waar elke rit een viering is van verfijning en uitmuntendheid.</p>
        </div>
    </section>
 
    <div class="car-container">
        <div class="car-card">
            <img src="rs6png.png" alt="Audi RS6 Plus Avant">
            <h3>Audi RS6 Plus Avant 5.0 TFSI</h3>
            <p>Aankoopprijs | € 60.000,-</p>
            <button>Ga naar auto's</button>
        </div>
 
        <div class="car-card">
            <img src="gwagon.png" alt="Mercedes Benz G-wagon">  
            <h3>Mercedes Benz G-wagon</h3>
            <p>Aankoopprijs | € 55.000,-</p>
            <button>Ga naar auto's</button>
        </div>
 
        <div class="car-card">
            <img src="lamborgini.png" alt="Lamborghini Urus">
            <h3>Lamborghini Urus</h3>
            <p>Aankoopprijs</p>
            <button>Ga naar auto's</button>
        </div>
    </div>
 
    <footer>
    <div class="footer-container">
        <div class="contact-info">
            <h2>Contactgegevens</h2>
            <ul>
                <li><strong>E-Mail:</strong> info@tonobien.nl</li>
                <li><strong>Telefoon:</strong> +31 123 456 789</li>
                <li><strong>Adres:</strong> Straatnaam 123, 1234 AB Stad</li>
            </ul>
        </div>
 
        <div class="social-media">
            <h2>Volg ons</h2>
            <ul>
                <li><a href="#" target="_blank">Fasbook</a></li>
                <li><a href="#" target="_blank">Twitter</a></li>
                <li><a href="#" target="_blank">Instagram</a></li>
            </ul>
        </div>
    </div>
 
    <div class="footer-bottom">
        <p>&copy; 2024 Tonobien Autobedrijf Verhuur. Alle rechten voorbehouden.</p>
    </div>
</footer>
 
</body>
</html>