<?php
 
class Database
{
    public $pdo;
 
    public function __construct($db = 'autozaak', $user = 'root', $pass = '', $host = 'localhost:3307')
    {
        try {
            // Establish a database connection
            $this->pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }
 
    public function selectDataByEmail($email)
    {
        // Retrieve user data by email
        $stmt = $this->pdo->prepare("SELECT * FROM klanten WHERE Emailadres = :Emailadres");
        $stmt->execute(['Emailadres' => $email]);
 
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
    public function addUser(User $user)
    {
        try {
            // Add user to the database
            $hashedPassword = $user->HashedPassword();
            $sql = "INSERT INTO klanten (Naam, Adres, Rijbewijsnummer, Telefoonnummer, Emailadres, Wachtwoord) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$user->Name, $user->Adres, $user->Rijbewijsnummer, $user->Telefoonnummer, $user->Emailadres, $hashedPassword]);
        } catch (PDOException $e) {
            throw new Exception("Error adding user to database: " . $e->getMessage());
        }
    }
}
 
class User
{
    private $db;
 
    public function __construct()
    {
        // Instantiate Database class
        $this->db = new Database();
    }
 
    public function customerLogin($email, $password)
    {
        try {
            // Authenticate user during login
            $user = $this->db->selectDataByEmail($email);
 
            if ($user && (password_verify($password, $user['Wachtwoord']) || $password == $user['Wachtwoord'])) {
                return true;
            }
 
            return false;
        } catch (PDOException $e) {
            die("Error during login: " . $e->getMessage());
        }
    }
 
    public function createCustomerAccount($name, $email, $password, $address, $licenseNumber, $phoneNumber)
    {
        try {
            // Create a new customer account
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO klanten (Naam, Adres, Rijbewijsnummer, Emailadres, Telefoonnummer, Wachtwoord) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $this->db->pdo->prepare($sql);
            $stmt->execute([$name, $address, $licenseNumber, $email, $phoneNumber, $hashedPassword]);
 
            echo "Account successfully created!";
        } catch (PDOException $e) {
            die("Error creating customer account: " . $e->getMessage());
        }
    }
 
    public function registerUser(User $user)
    {
        try {
            // Register a new user
            $existingUser = $this->db->selectDataByEmail($user->Emailadres);
            if ($existingUser) {
                throw new Exception('<p>Email is already registered. Please use a different email.</p>');
            }
            $this->db->addUser($user);
            echo '<p>Registration successful. You can now log in.</p>';
            header('Location: login.php');
 
        } catch (Exception $e) {
            echo "Registration failed: " . $e->getMessage();
        }
    }
 
    public function HashedPassword()
    {
        // Hash user password
        return password_hash($this->Wachtwoord, PASSWORD_DEFAULT);
    }
    public function getCars()
    {
        try {
            // Retrieve list of cars from the database
            $stmt = $this->pdo->query("SELECT * FROM cars"); // Adjust the table name as per your database structure
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            throw new Exception("Error fetching cars from database: " . $e->getMessage());
        }
    }

}
?>