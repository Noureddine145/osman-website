<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <div>
    <nav class="hoofdpagina">
        <p>Tonobien.nl</p>
        <a href="http://localhost/osman%20data%20Niveau%204/data%20toets%20leerjaar%202%20periode%202/">Home</a>
        <a href="http://localhost/osman%20data%20Niveau%204/data%20toets%20leerjaar%202%20periode%202/auto's.php">Auto's</a>
        <a href="http://localhost/osman%20data%20Niveau%204/data%20toets%20leerjaar%202%20periode%202/contact.php">Inloggen</a>
    </nav>
    </div>

</body>
</html>
<style>
    .hoofdpagina {
        display: flex;
        justify-content: space-around;
        background-color: rgb(0, 0, 0);
        color: white;
    }

    .hoofdpagina a {
        color: white;
        padding-top: 12px;
    }
</style>