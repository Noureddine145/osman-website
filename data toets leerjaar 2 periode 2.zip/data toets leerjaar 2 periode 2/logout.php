<?php
// Start session
session_start();
 
// Unset session variable to indicate user is logged out
unset($_SESSION['user_logged_in']);
 
// Redirect to the login page
header("Location: home.php");
exit();
?>
 