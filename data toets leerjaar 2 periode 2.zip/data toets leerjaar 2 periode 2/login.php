<?php
 
require_once 'db.php';
session_start();
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
 
 
    if (empty($email) || empty($password)) {
        echo "Email and password are required!";
    } else {
        $user = new User();
        if ($user->customerLogin($email, $password)) {
            $_SESSION['user_logged_in'] = true;
            header('Location: home.php');
        } else {
            echo "Invalid email or password!";
        }
    }
}
 
 
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in']) {
    echo '<p><a href="logout.php">Logout</a></p>';
} else {
 
    echo '<h2>Login</h2>
        <form method="post">
            <label for="email">Email:</label>
            <input type="email" name="email" required><br>
 
            <label for="password">Password:</label>
            <input type="password" name="password" required><br>
 
            <input type="submit" value="Login">
        </form>
        <p>Not registered? <a href="register.php">Register here</a></p>';
}
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Tonobien</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: gray;
            color: white;
        }

        header {
            background-color: black;
            color: white;
            padding: 20px;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }

        .logo {
            font-size: 24px;
            color: white;
            text-decoration: none;
            font-weight: 700;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 12px;
            border-bottom: 2px solid transparent;
            transition: border-bottom 0.3s ease-in-out;
        }

        .nav-links a:hover {
            border-bottom: 2px solid #3498db;
        }

        form {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: #333;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #3498db;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #217dbb;
        }

        a {
            color: #3498db;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
